# PDS Practicals

Python for Data Science (BE05000231)

This repository contains all 20 practical programs from the PDS practical list.

## Requirements

- Python 3.x
- pandas
- numpy
- scipy
- scikit-learn
- matplotlib
- beautifulsoup4
- mysql-connector-python

Install required libraries:

```bash
pip install -r requirements.txt
```

## Practical List

1. Variables, Data Types and Operators
2. List, Tuple, Set, Dictionary and String
3. Conditional Statements and Loops
4. Functions and Modules
5. File Handling
6. Exception Handling
7. MySQL CRUD Operations
8. Descriptive Statistics
9. Data Science Life Cycle and Data Analysis
10. NumPy Operations
11. Pandas Operations
12. SciPy Statistics
13. BeautifulSoup HTML Parsing
14. Basic Machine Learning
15. Binomial and Poisson Distributions
16. Normal, Exponential Distribution and CLT
17. One Sample T-Test
18. Data Cleaning
19. Data Preprocessing
20. Data Visualization

## How to Run

Open a practical folder and run its Python file:

```bash
python practical_01.py
```

Each practical is written in a simple beginner-friendly style.

## Note

Practical 7 requires a local MySQL server and a database named `pds`.
