# Unit 2 - File Handling, Exception Handling & MySQL
Practicals 5 to 7.
