# Practical 6
# Exception Handling

try:
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))
    result = a / b

except ValueError:
    print("Please enter numbers only.")

except ZeroDivisionError:
    print("Cannot divide by zero.")

else:
    print("Result:", result)

finally:
    print("Program completed.")

try:
    age = int(input("\nEnter your age: "))

    if age < 18:
        raise Exception("Age must be 18 or above.")

    print("You are eligible.")

except Exception as e:
    print("Error:", e)
