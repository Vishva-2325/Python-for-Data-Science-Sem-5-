# Unit 1 - Introduction, Data Types, Operators, Loops & Functions
Practicals 1 to 4.
