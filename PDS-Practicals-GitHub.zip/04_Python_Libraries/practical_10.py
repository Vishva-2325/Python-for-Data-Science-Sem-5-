# Practical 10
# NumPy Array Operations

import numpy as np

arr = np.array([
    [1, 2, 3],
    [4, 5, 6]
])

print("Array:")
print(arr)

print("\nIndexing:")
print(arr[0, 1])

print("\nSlicing:")
print(arr[:, 0])

numbers = np.array([1, 2, 3, 4, 5, 6])
new_array = numbers.reshape(2, 3)

print("\nReshaped Array:")
print(new_array)

a = np.array([1, 2, 3])
print("\nBroadcasting:")
print(a + 10)

print("\nMathematical Operations")
print("Addition:", np.add(a, 2))
print("Square:", np.square(a))
print("Sum:", np.sum(a))
print("Mean:", np.mean(a))
print("Maximum:", np.max(a))
print("Minimum:", np.min(a))
