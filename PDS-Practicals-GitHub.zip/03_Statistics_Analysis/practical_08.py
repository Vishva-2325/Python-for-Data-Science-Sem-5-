# Practical 8
# Descriptive Statistics

import statistics

data = [10, 20, 20, 30, 40, 50, 60, 70]

mean = statistics.mean(data)
median = statistics.median(data)
mode = statistics.mode(data)
variance = statistics.variance(data)
standard_deviation = statistics.stdev(data)
data_range = max(data) - min(data)

quartiles = statistics.quantiles(data, n=4)
q1 = quartiles[0]
q3 = quartiles[2]
iqr = q3 - q1

print("Data:", data)
print("Mean:", mean)
print("Median:", median)
print("Mode:", mode)
print("Variance:", variance)
print("Standard Deviation:", standard_deviation)
print("Range:", data_range)
print("Q1:", q1)
print("Q2:", quartiles[1])
print("Q3:", q3)
print("IQR:", iqr)
