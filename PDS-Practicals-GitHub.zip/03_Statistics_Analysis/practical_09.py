# Practical 9
# Data Science Life Cycle and Data Analysis

import pandas as pd
import matplotlib.pyplot as plt

data = pd.DataFrame({
    "StudyHours": [2, 3, 4, 5, 6],
    "Attendance": [70, 75, 80, 85, 90],
    "Marks": [55, 60, 68, 75, 85]
})

print("Dataset:")
print(data)

print("\nUnivariate Analysis")
print(data["Marks"].describe())

plt.hist(data["Marks"])
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.title("Marks Distribution")
plt.show()

print("\nBivariate Analysis")
print(data[["StudyHours", "Marks"]].corr())

plt.scatter(data["StudyHours"], data["Marks"])
plt.xlabel("Study Hours")
plt.ylabel("Marks")
plt.title("Study Hours vs Marks")
plt.show()

print("\nMultivariate Analysis")
print(data.corr())

plt.scatter(data["StudyHours"], data["Marks"],
            s=data["Attendance"] * 3)
plt.xlabel("Study Hours")
plt.ylabel("Marks")
plt.title("Multivariate Analysis")
plt.show()
