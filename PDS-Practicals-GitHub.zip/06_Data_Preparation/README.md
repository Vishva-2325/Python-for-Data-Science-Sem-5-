# Unit 6 - Data Preparation & Preprocessing
Practicals 18 and 19.
